#!/usr/bin/env powershell

C:\"Program Files"\"Puppet Labs"\Puppet\bin\puppet facts upload
