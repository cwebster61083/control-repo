[CmdletBinding()]
Param(
    [string]$directory = 'C:\Program Files (x86)'
)

$output = Get-ChildItem -Path $directory -Recurse -ErrorAction SilentlyContinue | ConvertTo-Json -Compress

$output