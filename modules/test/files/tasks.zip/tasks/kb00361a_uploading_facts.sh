#!/bin/bash


/opt/puppetlabs/bin/puppet facts upload

echo "KB3061a Task ended   $(date +%s)    --"
